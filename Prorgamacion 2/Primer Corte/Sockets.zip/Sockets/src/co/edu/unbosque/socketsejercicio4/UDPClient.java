package co.edu.unbosque.socketsejercicio4;

public class UDPClient {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
