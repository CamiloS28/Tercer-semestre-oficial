package co.edu.unbosque.taller;

import java.util.Scanner;

public class Matriz {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		System.out.println("Ingrese el numero de filas y columnas de la matriz");
		int filas_columnas = sc.nextInt();
		int[][] matriz = new int[filas_columnas][filas_columnas];

		for (int i = 0; i < matriz.length; i++) {
			for (int j = 0; j < matriz.length; j++) {
				System.out.println("Ingrese el valor para la psición [" + i + "][" + j + "]: ");
				matriz[i][j] = sc.nextInt();
			}
		}
		System.out.println("Matriz original:");
		imprimirMatriz(matriz);
		
		ordenarFilas(matriz);
		
		System.out.println("Matriz ordenada");
		imprimirMatriz(matriz);
		

	}
	public static void ordenarFilas(int[][] matriz) {
		for(int i = 0; i <matriz.length; i++) {
			quicksort(matriz[i], 0, matriz[i].length-1);
		}
	}
	public static void quicksort(int[] fila, int izquierda, int derecha) {
		int i = izquierda, j = derecha;
		int pivote = fila[(izquierda + derecha)/2];

		while(i <= j) {
			while(fila[i] < pivote) {
				i++;
			}
			while (fila[j] > pivote) {
				j--;
			}
			if(i <= j) {
				int temp = fila[i];
				fila[i] = fila[j];
				fila[j] = temp;
				i++;
				j--;
			}
		}

		if(izquierda < j) {
			quicksort(fila, izquierda, j);
		}
		if(i < derecha) {
			quicksort(fila, i, derecha);
		}

	}
	public static void imprimirMatriz(int[][] matriz) {
		int filas = matriz.length;
		int columnas = matriz[0].length;
		
		for (int j = 0; j < filas; j++) {
			System.out.print("____");
		}

		System.out.println("");

		for (int i = 0; i < matriz.length; i++) {
			for (int j = 0; j < matriz.length; j++) {
				System.out.print("|" + matriz[i][j] + " ");
			}
			System.out.println("|");

			if (i < filas - 1) {
				for (int j = 0; j < columnas; j++) {
					System.out.print("____");
				}
				System.out.println("");
			}
		}
		for (int j = 0; j < filas; j++) {
			System.out.print("____");
		}
		System.out.println("");
	}
}
