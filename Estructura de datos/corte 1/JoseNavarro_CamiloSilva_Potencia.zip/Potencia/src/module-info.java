/**
 * 
 */
/**
 * @author camilo
 *
 */
module Potencia {
}